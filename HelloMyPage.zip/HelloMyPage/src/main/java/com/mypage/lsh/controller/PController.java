package com.mypage.lsh.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PController {
	
	@RequestMapping("/python_project")
	public String python_project() {
		
		return "python_project";
	}
}