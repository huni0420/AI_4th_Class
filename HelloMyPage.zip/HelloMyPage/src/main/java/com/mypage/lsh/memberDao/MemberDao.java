package com.mypage.lsh.memberDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;

import com.mypage.lsh.utill.Constant;

public class MemberDao {

	DataSource datasource;
	
	JdbcTemplate template = null;
	
	public MemberDao() {
		template = Constant.template;
	}
	
	public void signup(final String mId,final String mPassword,final String mName,final String mPhone,final String mGender) {
		template.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				String query = "insert into member_n (mId,mPassword,mName,mPhone,mGender) values (?,?,?,?,?)";
				PreparedStatement pstmt = con.prepareStatement(query);
				pstmt.setString(1, mId);
				pstmt.setString(2, mPassword);
				pstmt.setString(3, mName);
				pstmt.setString(4, mPhone);
				pstmt.setString(5, mGender);
				
				return pstmt;
			}
		});
	}
}
