package com.mypage.lsh.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mypage.lsh.service.Service;
import com.mypage.lsh.service.SignupService;

@Controller
public class MController {
	Service service;
	
	@RequestMapping("/signup_page")
	public String signup_page(Model model) {
		
		return "signup_page";
	}
	
	@RequestMapping("signup")
	public String signup(HttpServletRequest request, Model model) {
		model.addAttribute("request", request);
		service = new SignupService();
		service.execute(model);
		
		return "redirect:/";
	}
	
	@RequestMapping("/login_page")
	public String login_page(Model model) {
		
		return "login_page";
	}
	
	@RequestMapping("login/")
	public String login(HttpServletRequest request,Model model)
	{
		return "Login/login_home";
	}
}
