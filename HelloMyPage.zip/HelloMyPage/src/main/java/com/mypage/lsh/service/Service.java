package com.mypage.lsh.service;

import org.springframework.ui.Model;

public interface Service {
	public void execute(Model model);
}
