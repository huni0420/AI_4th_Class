package com.mypage.lsh.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.mypage.lsh.boardDao.BoardDao;

public class DeleteService implements Service {

	@Override
	public void execute(Model model) {
		Map<String, Object> map = model.asMap();
		HttpServletRequest request = (HttpServletRequest) map.get("request");
		String bId = request.getParameter("bId");
		
		BoardDao dao = new BoardDao();
		dao.delete(bId);
	}

}
