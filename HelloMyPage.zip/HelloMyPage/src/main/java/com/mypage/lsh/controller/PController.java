package com.mypage.lsh.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PController {
	
	@RequestMapping("/login/spring_project")
	public String spring_project() {
		
		return "Login/spring_project";
	}
	
	@RequestMapping("/login/python_project")
	public String  loginpython_project() {
		
		return "Login/python_project";
	}
}

