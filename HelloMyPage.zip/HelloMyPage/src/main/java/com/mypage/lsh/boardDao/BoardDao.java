package com.mypage.lsh.boardDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.mypage.lsh.boardDto.BoardDto;
import com.mypage.lsh.utill.Constant;

/*bId,bName,bTitle,bContent,bDate,bHit,bGroup,bStep,bIndent*/
public class BoardDao {
	
	DataSource datasource;
	
	JdbcTemplate template = null;
	
	public BoardDao() {
		template = Constant.template;
	}
	
	public ArrayList<BoardDto> board(){
		
		String query = "select bId,bName,bTitle,bContent,bDate,bHit,bGroup,bStep,bIndent from board order by bGroup desc,bStep asc";
		return (ArrayList<BoardDto>) template.query(query, new BeanPropertyRowMapper<BoardDto>(BoardDto.class));
	}
	
	public BoardDto board_view(String strID) {
		upHit(strID);
		String query = "select bId,bName,bTitle,bContent,bDate,bHit,bGroup,bStep,bIndent from board where bId = " + strID;
		return template.queryForObject(query, new BeanPropertyRowMapper<BoardDto>(BoardDto.class));
	}
	
	public void write(final String bName,final String bTitle,final String bContent) {
		template.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				String query = "insert into board (bId,bName,bTitle,bContent,bHit,bGroup,bStep,bIndent) values (board_seq.nextval,?,?,?,0,board_seq.currval,0,0)";
				PreparedStatement pstmt = con.prepareStatement(query);
				pstmt.setString(1, bName);
				pstmt.setString(2, bTitle);
				pstmt.setString(3, bContent);
				
				return pstmt;
			}
		});
	}
	
	public void modify(String bId, String bName, String bTitle, String bContent) {
		String query = "update board set bName = ?, bTitle = ?, bContent = ? where bId = ?";
		template.update(query, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, bName);
				ps.setString(2, bTitle);
				ps.setString(3, bContent);
				ps.setInt(4, Integer.parseInt(bId));
			}
		});
	}
	
	public BoardDto board_reply_view(final String strID) {
		upHit(strID);
		String query = "select bId,bName,bTitle,bContent,bDate,bHit,bGroup,bStep,bIndent from board where bId = " + strID;
		return template.queryForObject(query, new BeanPropertyRowMapper<BoardDto>(BoardDto.class));
	}
	
	public void board_reply(final String bId,final String bName,final String bTitle,final String bContent, final String bGroup,final String bStep,final String bIndent) {
		board_reply_shape(bGroup,bStep);
		String query = "insert into board (bId, bName, bTitle, bContent, bGroup, bStep, bIndent) values (board_seq.nextval,?,?,?,?,?,?)";
		template.update(query, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, bName);
				ps.setString(2, bTitle);
				ps.setString(3, bContent);
				ps.setInt(4, Integer.parseInt(bGroup));
				ps.setInt(5, Integer.parseInt(bStep)+1);
				ps.setInt(6, Integer.parseInt(bIndent)+1);
			}
		});
	}
	
	public void board_reply_shape(final String strGroup, final String strStep) {
		String query = "update board set bStep = bStep + 1 where bGroup = ? and bStep > ?";
		template.update(query, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, Integer.parseInt(strGroup));
				ps.setInt(2, Integer.parseInt(strStep));
			}
		});
	}
	
	public void delete(final String strID) {
		String query = "delete from board where bId = ?";
		template.update(query, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, Integer.parseInt(strID));
			}
		});
	}
	
	private void upHit(final String bId) {
		String query = "update board set bHit = bHit + 1 where bId = ?";
		
		template.update(query, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1,Integer.parseInt(bId));
				}
		});
	}
}
