package com.mypage.lsh.service;

import java.util.ArrayList;

import org.springframework.ui.Model;

import com.mypage.lsh.boardDao.BoardDao;
import com.mypage.lsh.boardDto.BoardDto;

public class BoardService implements Service {

	@Override
	public void execute(Model model) {
		BoardDao dao = new BoardDao();
		ArrayList<BoardDto>dtos = dao.board();
		
		model.addAttribute("board",dtos);

	}

}
