package com.mypage.lsh.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mypage.lsh.service.BoardService;
import com.mypage.lsh.service.ContentService;
import com.mypage.lsh.service.DeleteService;
import com.mypage.lsh.service.ModifyService;
import com.mypage.lsh.service.ReplyService;
import com.mypage.lsh.service.ReplyViewService;
import com.mypage.lsh.service.Service;
import com.mypage.lsh.service.WriteService;
import com.mypage.lsh.utill.Constant;

@Controller
public class BController {
	Service service;
	
	public JdbcTemplate template;
	
	@Autowired
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
		Constant.template = this.template;
	}
	
	@RequestMapping("/board")
	public String board(Model model)
	{
		service = new BoardService();
		service.execute(model);
		
		return "board";
	}
	
	@RequestMapping("/board_write")
	public String board_write(Model model)
	{
		
		return "board_write";
	}
	
	@RequestMapping("write")
	public String write(HttpServletRequest request,Model model)
	{
		model.addAttribute("request",request);
		service = new WriteService();
		service.execute(model);
		
		return "redirect:board";
	}
	
	@RequestMapping("board_manage")
	public String board_manage(HttpServletRequest request, Model model) {
		model.addAttribute("request",request);
		service = new ContentService();
		service.execute(model);
		
		return "board_manage";
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/modify")
	public String modify(HttpServletRequest request,Model model) {
		
		model.addAttribute("request",request);
		service = new ModifyService();
		service.execute(model);
		return "redirect:board";
	}
	
	@RequestMapping("/board_reply")
	public String board_reply(HttpServletRequest request,Model model) {
		
		model.addAttribute("request",request);
		service = new ReplyViewService();
		service.execute(model);
		
		return "board_reply";
	}
	
	@RequestMapping("/reply")
	public String reply(HttpServletRequest request,Model model) {
		
		model.addAttribute("request",request);
		service = new ReplyService();
		service.execute(model);
		
		return "redirect:board";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request, Model model) {
		
		model.addAttribute("request",request);
		service = new DeleteService();
		service.execute(model);
		
		return "redirect:board";
	}
}
