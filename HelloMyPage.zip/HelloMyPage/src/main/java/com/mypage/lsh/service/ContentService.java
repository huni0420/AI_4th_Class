package com.mypage.lsh.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.mypage.lsh.boardDao.BoardDao;
import com.mypage.lsh.boardDto.BoardDto;

public class ContentService implements Service {

	@Override
	public void execute(Model model) {
		Map<String,Object> map = model.asMap();
		HttpServletRequest request = (HttpServletRequest) map.get("request");
		String bId = request.getParameter("bId");
		
		BoardDao dao = new BoardDao();
		BoardDto dto = dao.board_view(bId);
		model.addAttribute("board_view",dto);
	}
}