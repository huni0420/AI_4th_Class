package com.mypage.lsh.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.mypage.lsh.memberDao.MemberDao;


public class SignupService implements Service {

	@Override
	public void execute(Model model) {
		// TODO Auto-generated method stub
		Map<String, Object> map = model.asMap();
		HttpServletRequest request = (HttpServletRequest) map.get("request");
		
		String mId = request.getParameter("mId");
		String mPassword = request.getParameter("mPassword");
		String mName = request.getParameter("mName");
		String mPhone = request.getParameter("mPhone");
		String mGender = request.getParameter("mGender");
		
		MemberDao dao = new MemberDao();
		dao.signup(mId,mPassword,mName,mPhone,mGender);
	}
}
